"""
STIR CT conversion for Y-90
===========================

Convert the CT series of a measured Y-90 phantom acquisition into attenuation
and density maps on the SPECT reconstruction grid with STIR.

The CT is a 656-slice Mediso acquisition. The slice files are not stored in
spatial order, so they are sorted by ``ImagePositionPatient`` before the volume
is built. The reconstruction grid is the vendor ``umap_zoomed`` grid: 128
voxels of 4.2578 mm. Its attenuation map has no recorded photon energy and is
used here only as a registration reference, never converted to density.

The STIR route writes the CT into an Interfile image expressed in the same
physical frame as the target, then calls ``zoom_image`` with
``preserve_values``. HU values must not be scaled like counts. Only axial,
axis-aligned CT geometry is accepted; an oblique series is rejected rather
than silently resampled.

The page ends with a small matched reconstruction: the measured acquisition is
reconstructed with no attenuation correction and with the CT-derived 150 keV
map. The acquisition, initial support, subsets, subiterations and zero scatter
are identical. The final figure shows the raw images and the same 10 mm FWHM
Gaussian display smoothing applied to both arms, with the raw trace kept in the
profile; the smoothing is display-only and is not part of the reconstruction.
This is a conversion sanity check, not an accuracy or ranking study. See
:doc:`plot_17_y90_effective_energy` for the attenuation-energy comparison and
:doc:`plot_18_y90_mc_scatter` for the Monte Carlo scatter case study.
"""

# %%
# Setup
# -----
# The tutorial needs the Y-90 data (set ``SIMIND_CONNECTOR_Y90_DATA``), NumPy,
# pydicom, matplotlib, SciPy and STIR.

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pydicom
from scipy.ndimage import binary_erosion, gaussian_filter
from scipy.ndimage import shift as shift_image

from simind_python_connector.converters.attenuation import (
    hu_to_attenuation,
    hu_to_density_schneider,
)
from simind_python_connector.datasets import fetch_y90_phantom


VOXEL_SIZE_MM = 4.2578
MATRIX_SIZE = 128
GRID_CENTRE = (MATRIX_SIZE - 1) / 2.0
ENERGY_KEV = 150.0
# Small matched reconstruction endpoint: the same measured acquisition, initial
# support, subset count and subiteration budget in both arms. The only change is
# the CT-derived 150 keV attenuation map. No scatter and no PSF are modelled.
RECON_SUBSETS = 12
RECON_ITERATIONS = 4
RECON_SUBITERATIONS = RECON_SUBSETS * RECON_ITERATIONS
# Display-only Gaussian smoothing. The measured acquisition has about two
# counts per projection bin, so the unregularised OSEM images are dominated by
# Poisson speckle. The same 10 mm FWHM filter is applied to both arms and the
# raw panels are kept beside it; the reconstruction itself is unchanged.
DISPLAY_FWHM_MM = 10.0
DISPLAY_SIGMA_VOX = DISPLAY_FWHM_MM / (2.0 * np.sqrt(2.0 * np.log(2.0))) / VOXEL_SIZE_MM
# Frozen hot-sphere centre from the independent attenuation-only reconstruction;
# it is used to choose the displayed slice, not to fit anything.
HOT_SPHERE_CENTRE_MM = (-77.43, -181.69, -576.20)


def _shown(path):
    """Show a path relative to the working directory, or just its name."""
    path = Path(path)
    try:
        return path.resolve().relative_to(Path.cwd().resolve())
    except ValueError:
        return path.name


# %%
# Read the CT series
# ------------------
# A voxel-centre affine maps grid indices ``(i, j, k)`` to patient LPS
# coordinates ``(x, y, z)``. The volume itself is stored as ``(k, j, i)``,
# i.e. ``(z, y, x)``. Only axial, axis-aligned geometry is accepted.


@dataclass
class CTSeries:
    """One DICOM CT series: HU volume, LPS affine and sorted slice metadata."""

    hu: np.ndarray
    affine: np.ndarray
    slices: list
    series_uid: str
    frame_uid: str


def _is_axial(row_direction, column_direction, normal):
    axes = np.abs(np.vstack([row_direction, column_direction, normal]))
    cardinal = np.isclose(axes.max(axis=1), 1.0, atol=1e-4) & np.isclose(
        axes.sum(axis=1), 1.0, atol=1e-4
    )
    return bool(cardinal.all() and abs(normal[2]) > 0.999)


def read_ct_series(ct_directory):
    """Read one CT series into a sorted HU volume and a voxel-centre affine."""
    paths = sorted(Path(ct_directory).glob("*.dcm"))
    if not paths:
        raise FileNotFoundError(f"No DICOM files found in {ct_directory}")

    headers = [pydicom.dcmread(path, stop_before_pixels=True) for path in paths]
    series_uids = {str(header.SeriesInstanceUID) for header in headers}
    frames = {str(getattr(header, "FrameOfReferenceUID", "")) for header in headers}
    if len(series_uids) != 1:
        raise ValueError("CT directory contains more than one series")
    if len(frames) != 1:
        raise ValueError("CT slices use different frames of reference")
    if len({str(header.SOPInstanceUID) for header in headers}) != len(headers):
        raise ValueError("CT series repeats a SOP Instance UID")

    rows = {int(header.Rows) for header in headers}
    columns = {int(header.Columns) for header in headers}
    orientations = {
        tuple(round(float(value), 6) for value in header.ImageOrientationPatient)
        for header in headers
    }
    spacings = {
        tuple(round(float(value), 6) for value in header.PixelSpacing)
        for header in headers
    }
    if len(rows) != 1 or len(columns) != 1:
        raise ValueError("CT slices have different matrix sizes")
    if len(orientations) != 1:
        raise ValueError("CT slices have different orientations")
    if len(spacings) != 1:
        raise ValueError("CT slices have different pixel spacing")

    rows = rows.pop()
    columns = columns.pop()
    orientation = np.array(orientations.pop(), float)
    row_direction = orientation[:3]
    column_direction = orientation[3:]
    normal = np.cross(row_direction, column_direction)
    if not _is_axial(row_direction, column_direction, normal):
        raise ValueError("Only axial, axis-aligned CT geometry is supported")
    pixel_spacing = spacings.pop()

    positions = np.array([header.ImagePositionPatient for header in headers], float)
    projections = positions @ normal
    order = np.argsort(projections)
    paths = [paths[index] for index in order]
    headers = [headers[index] for index in order]
    positions = positions[order]
    projections = projections[order]

    steps = np.diff(projections)
    if np.any(steps <= 1e-6):
        raise ValueError("CT series contains duplicate slice positions")
    slice_spacing = float(np.median(steps))
    if not np.allclose(steps, slice_spacing, atol=1e-3):
        raise ValueError("CT slice spacing is not uniform (missing slices?)")
    expected = positions[0] + np.outer(projections - projections[0], normal)
    if not np.allclose(positions, expected, atol=1e-3):
        raise ValueError("CT slices do not share a common axis (mixed origins)")

    hu = np.empty((len(paths), rows, columns), dtype=np.float32)
    slices = []
    for index, path in enumerate(paths):
        dataset = pydicom.dcmread(path)
        slope = float(getattr(dataset, "RescaleSlope", 1.0))
        intercept = float(getattr(dataset, "RescaleIntercept", 0.0))
        hu[index] = dataset.pixel_array.astype(np.float32) * slope + intercept
        slices.append(
            {
                "path": str(path),
                "position": [float(value) for value in dataset.ImagePositionPatient],
                "slope": slope,
                "intercept": intercept,
                "table_height": float(getattr(dataset, "TableHeight", np.nan)),
            }
        )
        del dataset

    affine = np.eye(4)
    affine[:3, 0] = row_direction * pixel_spacing[1]
    affine[:3, 1] = column_direction * pixel_spacing[0]
    affine[:3, 2] = normal * slice_spacing
    affine[:3, 3] = slices[0]["position"]
    return CTSeries(
        hu=hu,
        affine=affine,
        slices=slices,
        series_uid=series_uids.pop(),
        frame_uid=frames.pop(),
    )


# %%
# Patient-to-SPECT frame
# ----------------------
# ``peak.dcm`` describes the detector plane, not a patient-coordinate image.
# The detector centre gives the grid centre in x and z. The y position is not
# in the NM header; the CT table height (-140 mm) supplies it in the shared
# frame of reference. No origin is re-derived from the images and no recentring
# is applied.


def patient_to_spect_affine(nm_file, ct_series):
    """Return the grid ``(i, j, k)`` -> patient LPS affine for the SPECT frame."""
    nm = pydicom.dcmread(nm_file, stop_before_pixels=True)
    if str(nm.FrameOfReferenceUID) != ct_series.frame_uid:
        raise ValueError("The NM and CT files use different frames of reference")
    detector = nm.DetectorInformationSequence[0]
    position = np.array(detector.ImagePositionPatient, float)
    orientation = np.array(detector.ImageOrientationPatient, float)
    centre = (
        position + (orientation[:3] + orientation[3:]) * GRID_CENTRE * VOXEL_SIZE_MM
    )
    table_height = ct_series.slices[0]["table_height"]
    if not np.isfinite(table_height):
        raise ValueError("The CT series has no TableHeight")

    affine = np.eye(4)
    affine[0, 0] = VOXEL_SIZE_MM
    affine[1, 1] = VOXEL_SIZE_MM
    affine[2, 2] = -VOXEL_SIZE_MM
    affine[0, 3] = centre[0] - GRID_CENTRE * VOXEL_SIZE_MM
    affine[1, 3] = table_height - GRID_CENTRE * VOXEL_SIZE_MM
    affine[2, 3] = centre[2] + GRID_CENTRE * VOXEL_SIZE_MM
    return affine


def read_umap(data_directory):
    """Read the vendor attenuation map on the SPECT grid, in ``(k, j, i)`` order."""
    values = np.fromfile(Path(data_directory) / "umap_zoomed.v", dtype="<f4").astype(
        np.float32
    )
    return values.reshape(MATRIX_SIZE, MATRIX_SIZE, MATRIX_SIZE)


# %%
# Registration report
# -------------------
# The metric is computed on the native 4.2578 mm grid before any reduction.
# Registration is assessed by normalized cross-correlation within a mask defined
# by CT coverage, CT HU > -400, positive vendor attenuation and finite values. We
# erode this mask once by one SPECT-grid voxel and keep the resulting mask fixed
# for every candidate translation. This reduces sensitivity to boundary
# differences between the sharp CT and the smoothed vendor attenuation map. The
# exact acceptance criterion remains a Euclidean residual of at most 1.0 voxel;
# the measured translation is not applied to the CT-derived maps.
#
# In this dataset, the vendor map has a thicker table-side body boundary and a
# fainter table than the CT-derived map. These differences bias the un-eroded
# correlation metric but cannot be corrected by a global translation. The table
# is therefore not treated as an anatomical registration landmark. This
# interior-focused check does not establish agreement of the body boundary or
# table attenuation.
#
# The report contains the zero-offset Pearson correlation, then the highest
# integer-search normalised cross-correlation (NCC) over a +/-5-voxel search and
# its signed ``(z, y, x)`` shift. A quadratic fit around the best integer shift
# refines the peak to subvoxel precision when the fit is negative definite,
# finite and locally bounded; otherwise the integer estimate is kept. A failed
# gate stops the tutorial before any accepted map is written.


GATE_VOXELS = 1.0

MASK_DEFINITION = (
    "CT coverage, CT HU > -400, positive vendor attenuation and finite values"
)
MASK_EROSION = "one 3-D connectivity-1 binary erosion, one voxel, border_value=0"


def _intersection_mask(coverage, hu_grid, umap, ct_map):
    return (
        coverage
        & (hu_grid > -400)
        & (umap > 0)
        & np.isfinite(ct_map)
        & np.isfinite(umap)
    )


def registration_mask(coverage, hu_grid, umap, ct_map):
    """Return the fixed body region used for every candidate translation."""
    return binary_erosion(
        _intersection_mask(coverage, hu_grid, umap, ct_map), iterations=1
    )


def _ncc(first, second, mask):
    first = first[mask] - first[mask].mean()
    second = second[mask] - second[mask].mean()
    denominator = np.sqrt((first * first).sum() * (second * second).sum())
    return float((first * second).sum() / denominator) if denominator > 0 else np.nan


def passes_gate(euclidean_voxels):
    """Return whether a measured offset meets the one-voxel gate."""
    return euclidean_voxels <= GATE_VOXELS


def quadratic_peak(scores, centre):
    """Return the subvoxel maximum around ``centre``, or None if the fit fails."""
    rows, values = [], []
    for dz in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                key = (centre[0] + dz, centre[1] + dy, centre[2] + dx)
                if key not in scores:
                    continue
                rows.append(
                    [
                        1,
                        dz,
                        dy,
                        dx,
                        dz * dz,
                        dy * dy,
                        dx * dx,
                        dz * dy,
                        dz * dx,
                        dy * dx,
                    ]
                )
                values.append(scores[key])
    if len(values) < 10:
        return None
    coefficients, *_ = np.linalg.lstsq(
        np.array(rows, float), np.array(values, float), rcond=None
    )
    if not np.all(np.isfinite(coefficients)):
        return None
    hessian = np.array(
        [
            [2 * coefficients[4], coefficients[7], coefficients[8]],
            [coefficients[7], 2 * coefficients[5], coefficients[9]],
            [coefficients[8], coefficients[9], 2 * coefficients[6]],
        ]
    )
    if not np.all(np.linalg.eigvalsh(hessian) < 0):
        return None
    gradient = np.array([coefficients[1], coefficients[2], coefficients[3]])
    try:
        subvoxel = -np.linalg.solve(hessian, gradient)
    except np.linalg.LinAlgError:
        return None
    if not np.all(np.isfinite(subvoxel)) or np.max(np.abs(subvoxel)) > 1.0:
        return None
    return subvoxel


def registration_report(
    ct_map,
    reference,
    mask,
    voxel_size_mm=VOXEL_SIZE_MM,
    max_shift=5,
    min_voxels=1000,
):
    """Measure the CT-to-SPECT offset on a fixed mask and apply the gate."""
    ct_map = np.asarray(ct_map, float)
    reference = np.asarray(reference, float)
    mask = np.asarray(mask, bool) & np.isfinite(ct_map) & np.isfinite(reference)
    report = {
        "region_voxels": int(mask.sum()),
        "zero_pearson": None,
        "best_integer_zyx": None,
        "best_ncc": None,
        "best_ncc_definition": "integer-search NCC",
        "offset_zyx": None,
        "offset_mm": None,
        "euclidean_voxels": None,
        "euclidean_mm": None,
        "refined_by": "integer",
        "passed": False,
        "status": "fail",
        "reason": "",
    }
    if mask.sum() < min_voxels:
        report["reason"] = "empty registration region"
        return report
    if np.std(ct_map[mask]) == 0 or np.std(reference[mask]) == 0:
        report["reason"] = "flat registration region"
        return report
    report["zero_pearson"] = float(np.corrcoef(ct_map[mask], reference[mask])[0, 1])

    # Crop to the mask plus the search margin so the search stays local.
    occupied = np.argwhere(mask)
    low = np.maximum(occupied.min(axis=0) - max_shift - 2, 0)
    high = np.minimum(occupied.max(axis=0) + max_shift + 3, mask.shape)
    crop = tuple(slice(start, stop) for start, stop in zip(low, high))
    ct_crop = ct_map[crop]
    reference_crop = reference[crop]
    mask_crop = mask[crop]

    scores = {}
    best = (-np.inf, (0, 0, 0))
    for dz in range(-max_shift, max_shift + 1):
        for dy in range(-max_shift, max_shift + 1):
            for dx in range(-max_shift, max_shift + 1):
                moved = shift_image(
                    ct_crop, (dz, dy, dx), order=1, mode="constant", cval=0.0
                )
                if not np.all(np.isfinite(moved[mask_crop])):
                    continue
                score = _ncc(moved, reference_crop, mask_crop)
                if not np.isfinite(score):
                    continue
                scores[(dz, dy, dx)] = score
                if score > best[0]:
                    best = (score, (dz, dy, dx))
    if not scores:
        report["reason"] = "no overlap survives the translation search"
        return report

    best_score, best_shift = best
    report["best_integer_zyx"] = [int(value) for value in best_shift]
    report["best_ncc"] = float(best_score)
    if max(abs(value) for value in best_shift) == max_shift:
        report["reason"] = "best integer shift reaches the search boundary"
        return report

    refined = np.array(best_shift, float)
    subvoxel = quadratic_peak(scores, best_shift)
    if subvoxel is not None:
        refined += subvoxel
        report["refined_by"] = "quadratic"

    distance = float(np.linalg.norm(refined))
    report.update(
        {
            "offset_zyx": refined.tolist(),
            "offset_mm": (refined * voxel_size_mm).tolist(),
            "euclidean_voxels": distance,
            "euclidean_mm": distance * voxel_size_mm,
            "passed": passes_gate(distance),
        }
    )
    if report["passed"]:
        report["status"] = "pass"
    else:
        report["reason"] = (
            f"offset {distance:.3f} voxels exceeds the {GATE_VOXELS:.1f}-voxel gate"
        )
    return report


# %%
# STIR resampling route
# ---------------------
# The Interfile builder writes a STIR image with a 0-based z index range and
# centred x/y ranges. Its origin is the physical coordinate of index (0, 0, 0):
# the first slice in z and the centre column and row in x/y. The CT array is
# reversed in z so that index 0 is the slice with the highest patient z. The
# target ``umap_zoomed`` image uses the same STIR conventions. Expressing both
# images in one physical frame is what makes the identity resampling correct.
# Coverage keeps only voxels that are fully inside the CT; partial edge voxels
# are treated as air so the resampler's default padding cannot look like tissue.


def read_first_pixel_offsets(header_file):
    """Return the target first-pixel offsets ``(x, y, z)`` in mm."""
    offsets = {}
    for line in Path(header_file).read_text().splitlines():
        stripped = line.strip().lstrip("!")
        if stripped.startswith("first pixel offset (mm)"):
            axis = int(stripped.split("[")[1].split("]")[0])
            offsets[axis] = float(stripped.split(":=")[1])
    if set(offsets) != {1, 2, 3}:
        raise ValueError(f"{header_file} has no complete first-pixel offset")
    return offsets[1], offsets[2], offsets[3]


def resample_to_spect(ct_series, target_affine, target_header, work_directory):
    """Resample CT HU onto the SPECT grid with ``zoom_image`` and return coverage."""
    import stir
    import stir.extra

    from simind_python_connector.builders import STIRSPECTImageDataBuilder

    stir.Verbosity.set(0)
    work_directory = Path(work_directory)
    work_directory.mkdir(parents=True, exist_ok=True)

    target_x, target_y, _ = read_first_pixel_offsets(target_header)
    centre = target_affine @ np.array([GRID_CENTRE, GRID_CENTRE, GRID_CENTRE, 1.0])
    x_shift = centre[0] - (target_x + GRID_CENTRE * VOXEL_SIZE_MM)
    y_shift = centre[1] - (target_y + GRID_CENTRE * VOXEL_SIZE_MM)
    z_top = target_affine[2, 3]
    highest_patient_z = max(entry["position"][2] for entry in ct_series.slices)

    row_spacing = float(np.linalg.norm(ct_series.affine[:3, 0]))
    column_spacing = float(np.linalg.norm(ct_series.affine[:3, 1]))
    slice_spacing = float(np.linalg.norm(ct_series.affine[:3, 2]))
    nz, ny, nx = ct_series.hu.shape
    ct_centre_x = ct_series.affine[0, 3] + (nx - 1) / 2.0 * ct_series.affine[0, 0]
    ct_centre_y = ct_series.affine[1, 3] + (ny - 1) / 2.0 * ct_series.affine[1, 1]
    ct_x = float(ct_centre_x - x_shift)
    ct_y = float(ct_centre_y - y_shift)
    ct_z = float(z_top - highest_patient_z)

    header = {
        "!matrix size [1]": str(nx),
        "!matrix size [2]": str(ny),
        "!matrix size [3]": str(nz),
        "scaling factor (mm/pixel) [1]": f"{row_spacing:.8f}",
        "scaling factor (mm/pixel) [2]": f"{column_spacing:.8f}",
        "scaling factor (mm/pixel) [3]": f"{slice_spacing:.8f}",
    }

    def build_image(name, array):
        builder = STIRSPECTImageDataBuilder(header, backend="stir")
        builder.set_pixel_array(array[::-1].astype(np.float32))
        base = work_directory / name
        builder.build(output_path=base)
        return stir.FloatVoxelsOnCartesianGrid.read_from_file(str(base) + ".hv")

    def set_origin(image, z, y, x):
        origin = stir.FloatCartesianCoordinate3D()
        origin[1], origin[2], origin[3] = z, y, x
        image.set_origin(origin)

    ct_image = build_image("ct_hu_input", ct_series.hu)
    set_origin(ct_image, ct_z, ct_y, ct_x)
    coverage_image = build_image("ct_coverage_input", np.ones_like(ct_series.hu))
    set_origin(coverage_image, ct_z, ct_y, ct_x)

    target = stir.FloatVoxelsOnCartesianGrid.read_from_file(str(target_header))
    output = target.get_empty_copy()
    stir.zoom_image(
        output, ct_image, stir.ZoomOptions(stir.ZoomOptions.preserve_values)
    )
    hu_grid = np.asarray(stir.extra.to_numpy(output), dtype=np.float32)

    coverage_output = target.get_empty_copy()
    stir.zoom_image(
        coverage_output,
        coverage_image,
        stir.ZoomOptions(stir.ZoomOptions.preserve_values),
    )
    coverage = np.asarray(stir.extra.to_numpy(coverage_output), dtype=np.float32) > 0.99
    hu_grid[~coverage] = -1000.0
    return hu_grid, coverage


# %%
# Figures and summary
# -------------------


def _pyplot():
    import matplotlib.pyplot as plt

    return plt


def _normalise(image, low, high):
    return np.clip((image - low) / (high - low), 0.0, 1.0)


def save_registration_overlay(path, ct_map, umap, report):
    """Save axial, coronal and sagittal overlays of the CT map and the reference."""
    plt = _pyplot()
    ct = _normalise(ct_map, 0.0, 0.25)
    reference = _normalise(umap, 0.0, 0.25)
    planes = [
        ("axial k=64", ct[64], reference[64]),
        ("coronal j=64", ct[:, 64, :], reference[:, 64, :]),
        ("sagittal i=64", ct[:, :, 64], reference[:, :, 64]),
    ]
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    for axis, (title, ct_plane, reference_plane) in zip(axes, planes):
        axis.imshow(np.dstack([ct_plane, reference_plane, np.zeros_like(ct_plane)]))
        axis.set_title(title)
        axis.axis("off")
    if report["euclidean_voxels"] is None:
        outcome = report["reason"] or "no registration"
    else:
        outcome = (
            f"{report['euclidean_voxels']:.3f} voxels, "
            f"{report['euclidean_mm']:.2f} mm ({report['status']})"
        )
    figure.suptitle(f"CT (red) and umap (green): {outcome}")
    figure.tight_layout()
    figure.savefig(path, dpi=130)


def save_maps(path, hu_grid, density, attenuation):
    """Save one axial slice of the HU, density and attenuation maps."""
    plt = _pyplot()
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    images = [
        (hu_grid[64], "CT HU on the SPECT grid", "gray", -1000.0, 1000.0, "HU"),
        (density[64], "Schneider density", "viridis", 0.0, 1.6, "g/cm³"),
        (
            attenuation[64],
            "Attenuation at 150 keV",
            "magma",
            0.0,
            0.25,
            "cm⁻¹",
        ),
    ]
    for axis, (image, title, cmap, low, high, label) in zip(axes, images):
        shown = axis.imshow(image, cmap=cmap, vmin=low, vmax=high)
        axis.set_title(title)
        axis.axis("off")
        figure.colorbar(shown, ax=axis, shrink=0.7, label=label)
    figure.tight_layout()
    figure.savefig(path, dpi=130)


def reconstruct_pair(acquisition_file, target_header, hu_grid, attenuation):
    """Reconstruct the measured data without and with the CT attenuation map.

    Both arms use the same acquisition, initial body support, 12 subsets and
    48 subiterations. The only difference is the SPECTUB attenuation image.
    """
    import stir

    stir.Verbosity.set(0)
    acquisition = stir.ProjData.read_from_file(str(acquisition_file))
    target = stir.FloatVoxelsOnCartesianGrid.read_from_file(str(target_header))
    support = np.ascontiguousarray((hu_grid > -400.0).astype(np.float32))
    attenuation_image = target.get_empty_copy()
    attenuation_image.fill(
        np.ascontiguousarray(np.asarray(attenuation, dtype=np.float32)[..., ::-1])
    )

    def reconstruct(use_attenuation):
        matrix = stir.ProjMatrixByBinSPECTUB()
        matrix.set_resolution_model(0.0, 0.0, False)
        if use_attenuation:
            matrix.set_attenuation_image_sptr(attenuation_image)
        projector = stir.ProjectorByBinPairUsingProjMatrixByBin()
        projector.set_proj_matrix_sptr(matrix)
        objective = stir.PoissonLogLikelihoodWithLinearModelForMeanAndProjData3DFloat()
        objective.set_proj_data_sptr(acquisition)
        objective.set_projector_pair_sptr(projector)
        objective.set_num_subsets(RECON_SUBSETS)
        reconstruction = stir.OSMAPOSLReconstruction3DFloat()
        reconstruction.set_objective_function(objective)
        reconstruction.set_num_subsets(RECON_SUBSETS)
        reconstruction.set_num_subiterations(RECON_SUBITERATIONS)
        # Do not write per-subiteration Interfile images into the working
        # directory; only the arrays below are needed.
        reconstruction.set_disable_output(True)
        image = target.get_empty_copy()
        image.fill(support)
        reconstruction.set_up(image)
        reconstruction.reconstruct(image)
        return np.asarray(image.as_array(), dtype=np.float32)

    return {
        "No attenuation correction": reconstruct(False),
        "CT 150 keV attenuation": reconstruct(True),
    }


def save_reconstruction_comparison(path, images, target_affine):
    """Save raw and display-smoothed reconstructions and a sphere profile.

    The display protocol shows the raw images and the same 10 mm FWHM Gaussian
    smoothing applied to both arms. The smoothing is display-only and is not
    part of either reconstruction. The profile keeps the raw single-voxel trace
    beside the smoothed one.
    """
    plt = _pyplot()
    centre_index = np.linalg.solve(
        target_affine, np.append(np.asarray(HOT_SPHERE_CENTRE_MM, float), 1.0)
    )
    k = int(round(centre_index[2]))
    j = int(round(centre_index[1]))
    names = list(images)
    arrays = [images[name] for name in names]
    smoothed = [gaussian_filter(array, sigma=DISPLAY_SIGMA_VOX) for array in arrays]
    limit = max(
        float(np.percentile(array[array > 0], 99.5))
        for array in smoothed
        if array.any()
    )
    short_names = {
        "No attenuation correction": "no AC",
        "CT 150 keV attenuation": "CT 150 keV",
    }
    figure = plt.figure(figsize=(11, 10), constrained_layout=True)
    grid = figure.add_gridspec(3, 2)
    raw_axes = [figure.add_subplot(grid[0, column]) for column in range(2)]
    smooth_axes = [figure.add_subplot(grid[1, column]) for column in range(2)]
    profile_axis = figure.add_subplot(grid[2, :])
    image_axes = []
    for axes, title, stack in (
        (raw_axes, "Raw", arrays),
        (smooth_axes, f"{DISPLAY_FWHM_MM:.0f} mm FWHM display-smoothed", smoothed),
    ):
        for axis, name, array in zip(axes, names, stack):
            shown = axis.imshow(array[k], cmap="viridis", vmin=0.0, vmax=limit)
            axis.set_title(f"{title}\n{short_names.get(name, name)}", fontsize=9)
            axis.axis("off")
            image_axes.append(axis)
    figure.colorbar(
        shown,
        ax=image_axes,
        shrink=0.6,
        label="reconstructed value (shared raw and smoothed scale)",
    )
    for index, name in enumerate(names):
        profile_axis.plot(
            arrays[index][k, j],
            color=f"C{index}",
            linestyle=":",
            linewidth=0.8,
            label=f"{name}, raw",
        )
        profile_axis.plot(
            smoothed[index][k, j],
            color=f"C{index}",
            linewidth=1.6,
            label=f"{name}, display smoothed",
        )
    profile_axis.set_xlabel("x (voxel)")
    profile_axis.set_ylabel("reconstructed value")
    profile_axis.set_title(
        f"Profile through the hot-sphere centre, k={k}; dotted is the raw trace"
    )
    profile_axis.legend(fontsize=8, ncol=2)
    figure.suptitle(
        f"Matched OSEM, {RECON_SUBSETS} subsets x {RECON_ITERATIONS} iterations, "
        "zero scatter, no PSF"
    )
    figure.savefig(path, dpi=130)
    return figure


def save_json(path, payload):
    with open(path, "w") as stream:
        json.dump(payload, stream, indent=1)


def clear_stale_outputs(output_directory):
    """Remove earlier accepted results so a rerun cannot present them as current."""
    for name in (
        "maps.png",
        "reconstruction_comparison.png",
        "summary.json",
        "registration.json",
        "registration_overlay.png",
        "UNACCEPTED.txt",
    ):
        (Path(output_directory) / name).unlink(missing_ok=True)


def write_unaccepted_summary(output_directory, report):
    """Record that the gate failed and that no accepted maps were published."""
    summary = {
        "status": "UNACCEPTED",
        "reason": report["reason"],
        "euclidean_voxels": report["euclidean_voxels"],
        "euclidean_mm": report["euclidean_mm"],
        "registration": report,
    }
    if report["euclidean_voxels"] is None:
        detail = f"Reason: {report['reason']}\n"
    else:
        detail = (
            f"Residual: {report['euclidean_voxels']:.3f} voxels "
            f"({report['euclidean_mm']:.2f} mm).\n"
            f"Reason: {report['reason']}\n"
        )
    save_json(Path(output_directory) / "summary.json", summary)
    (Path(output_directory) / "UNACCEPTED.txt").write_text(
        "Registration did not meet the one-voxel gate.\n"
        + detail
        + "No density or attenuation maps were published.\n"
    )


def accept_or_report(report, output_directory):
    """Return True to continue; record an unaccepted result and return False."""
    if report["passed"]:
        return True
    write_unaccepted_summary(output_directory, report)
    return False


# %%
# Run the tutorial
# ----------------


def run():
    data_directory = fetch_y90_phantom()
    output_directory = (
        Path(os.environ.get("SIMIND_EXAMPLES_OUTPUT", "output"))
        / "real_data"
        / "ct_conversion"
        / "stir"
    )
    output_directory.mkdir(parents=True, exist_ok=True)
    clear_stale_outputs(output_directory)

    ct_series = read_ct_series(data_directory / "ctac")
    target_affine = patient_to_spect_affine(data_directory / "peak.dcm", ct_series)
    print(
        f"CT volume: {ct_series.hu.shape}, HU {ct_series.hu.min():.0f} to "
        f"{ct_series.hu.max():.0f}"
    )
    print(f"CT LPS affine:\n{np.round(ct_series.affine, 4)}")
    print(f"SPECT LPS affine:\n{np.round(target_affine, 4)}")

    hu_grid, coverage = resample_to_spect(
        ct_series,
        target_affine,
        data_directory / "umap_zoomed.hv",
        output_directory / "work",
    )
    print(f"Target coverage: {coverage.mean():.1%}")

    umap = read_umap(data_directory)
    attenuation = hu_to_attenuation(hu_grid, ENERGY_KEV).astype(np.float32)

    region = registration_mask(coverage, hu_grid, umap, attenuation)
    report = registration_report(attenuation, umap, region)
    report["coverage_fraction"] = float(coverage.mean())
    report["mask"] = {
        "definition": MASK_DEFINITION,
        "erosion": MASK_EROSION,
        "region_voxels": report["region_voxels"],
    }
    historical = registration_report(
        attenuation, umap, _intersection_mask(coverage, hu_grid, umap, attenuation)
    )
    historical["role"] = "historical diagnostic only; not the acceptance metric"
    report["historical_full_mask"] = historical
    save_json(output_directory / "registration.json", report)
    save_registration_overlay(
        output_directory / "registration_overlay.png", attenuation, umap, report
    )
    print(
        "Registration: zero-offset Pearson "
        f"{report['zero_pearson']:.4f}, best integer NCC {report['best_ncc']:.4f} "
        f"at {report['best_integer_zyx']}"
    )
    print(f"Registration mask: {MASK_DEFINITION}")
    print(f"Mask erosion: {MASK_EROSION}")
    print(f"Fixed mask after erosion: {report['region_voxels']} voxels")
    if historical["euclidean_voxels"] is None:
        historical_outcome = historical["reason"]
    else:
        historical_outcome = (
            f"{historical['euclidean_voxels']:.3f} voxels = "
            f"{historical['euclidean_mm']:.2f} mm ({historical['status']})"
        )
    print(
        "Historical un-eroded mask (diagnostic only): "
        f"{historical['region_voxels']} voxels, {historical_outcome}"
    )
    if not accept_or_report(report, output_directory):
        print(
            "Offset (z, y, x): "
            f"{np.round(report['offset_zyx'], 3)} voxels = "
            f"{np.round(report['offset_mm'], 2)} mm"
        )
        print(
            f"Euclidean: {report['euclidean_voxels']:.3f} voxels = "
            f"{report['euclidean_mm']:.2f} mm -> UNACCEPTED "
            f"({report['reason']})"
        )
        print(
            "The STIR route is reported as unaccepted; no density or attenuation "
            "maps were published."
        )
        return

    density = hu_to_density_schneider(hu_grid).astype(np.float32)
    print(
        "Offset (z, y, x): "
        f"{np.round(report['offset_zyx'], 3)} voxels = "
        f"{np.round(report['offset_mm'], 2)} mm"
    )
    print(
        f"Euclidean: {report['euclidean_voxels']:.3f} voxels = "
        f"{report['euclidean_mm']:.2f} mm -> {report['status'].upper()}"
    )

    air = (hu_grid < -900) & coverage
    summary = {
        "registration": report,
        "maps": {
            "coverage_fraction": float(coverage.mean()),
            "air_fraction": float(air.sum() / coverage.sum()),
            "density_range_g_cm3": [
                float(density[coverage].min()),
                float(density[coverage].max()),
            ],
            "attenuation_range_cm1": [
                float(attenuation[coverage].min()),
                float(attenuation[coverage].max()),
            ],
            "energy_kev": ENERGY_KEV,
            "umap_energy": "not recorded; used only as a registration reference",
        },
    }
    save_json(output_directory / "summary.json", summary)
    save_maps(output_directory / "maps.png", hu_grid, density, attenuation)
    print("Running the matched no-attenuation and CT-attenuation reconstructions")
    recon_start = time.perf_counter()
    reconstructions = reconstruct_pair(
        data_directory / "peak.hs",
        data_directory / "umap_zoomed.hv",
        hu_grid,
        attenuation,
    )
    recon_seconds = time.perf_counter() - recon_start
    save_reconstruction_comparison(
        output_directory / "reconstruction_comparison.png",
        reconstructions,
        target_affine,
    )
    summary["reconstruction"] = {
        "subsets": RECON_SUBSETS,
        "iterations": RECON_ITERATIONS,
        "subiterations": RECON_SUBITERATIONS,
        "initial": "unit body support (HU > -400)",
        "additive_scatter": "zero in both",
        "resolution_model": "none",
        "attenuation_arms": list(reconstructions),
        "seconds": recon_seconds,
    }
    save_json(output_directory / "summary.json", summary)
    print(f"Matched reconstruction: {recon_seconds:.1f} s")
    print(f"Maps written to {_shown(output_directory)}")
    _pyplot().show()


if __name__ == "__main__":
    run()
